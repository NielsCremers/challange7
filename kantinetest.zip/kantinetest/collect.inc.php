<?php
$naam       = $_POST['tb_naam'];
$email      = $_POST['tb_email'];
$bericht    = $_POST['tb_bericht'];
?>