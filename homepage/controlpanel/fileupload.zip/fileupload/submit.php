<?php

error_reporting(E_ALL);
ini_set("display_errors", "on");


if (isset($_POST['submit'])) { // && !empty($_FILES['image']['name'])
    echo "test 1<br />";
    if (isset($_POST['submit']) && !empty($_FILES['image2']['name'])) {
        echo "test 2<br />";
        if (isset($_POST['submit']) && !empty($_FILES['image3']['name'])) {
            echo "test 3<br />";
            if (isset($_POST['submit']) && !empty($_FILES['image4']['name'])) {                
    if ($_FILES['image']['error'] != 0) {
        echo 'Something wrong with the file.';
    } else { 
        $naam = htmlspecialchars($_POST['naam']);
        $status = htmlspecialchars($_POST['status']);
        $prijs = htmlspecialchars($_POST['prijs']);     
        $type = htmlspecialchars($_POST['type']);
        $transmissie = htmlspecialchars($_POST['transmissie']);
        $brandstof = htmlspecialchars($_POST['brandstof']);
        $nummerbord = htmlspecialchars($_POST['nummerbord']);
        $bouwjaar =  htmlspecialchars($_POST['bouwjaar']);
        $km =  htmlspecialchars($_POST['km']);

       

        include "db_connection.php";

        $insert_sql = "INSERT INTO project_pdf (naam, photoname, prijs, type, transmissie, brandstof, nummerbord, bouwjaar, km, status)  
                        VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $file_name = $_FILES['image']['name'];
        $file_name = $_FILES['image2']['name2'];
        $file_name = $_FILES['image3']['name3'];
        $file_name = $_FILES['image4']['name4'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_tmp = $_FILES['image2']['tmp_name2'];
        $file_tmp = $_FILES['image3']['tmp_name3'];
        $file_tmp = $_FILES['image4']['tmp_name4'];
        $data = array($naam, $file_name);
        $stmt = $pdo->prepare($insert_sql);

        $stmt->execute($data);

        $lId =  $pdo->lastInsertId();
        mkdir("images/".$lId, 0777, true);


        $insert_sql = "INSERT INTO tb_photo (car_id, photoname)
        VALUES(?, ?)";
        $data = array($lId, $file_name);
        $stmt = $pdo->prepare($insert_sql);
        $stmt->execute($data);
        
        
        move_uploaded_file($file_tmp, "images/$lId/$file_name");
        move_uploaded_file($file_tmp, "images/$lId/$file_name2");
        move_uploaded_file($file_tmp, "images/$lId/$file_name3");
        move_uploaded_file($file_tmp, "images/$lId/$file_name4");
        echo "Het product is aangemaakt!";

    }
} else {
    echo "test 50<br />";
    //submit button was not clicked. No direct script navigation.
   //header('Location: choose_file.php');
}
        }
    }
}

        
    

echo "test 100";

//echo "<img src='images/$file_name' />";



//inset auto in de databse
//zorg dat je het laatste inserted id krijgt
//maak een nieuwe map voor de foto's 
//sla de foto / of foto''s op in de database
?>