<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous"/>
    <title>Producten toevoegen</title>

<center>
<h4 class="text-center" style="margin-top: 100px;">Product toevoegen</h4>
<div class="d-flex justify-content-center align-self-center" style="margin-top: 115px;">
    <form action="submit.php" method="post" accept-charset="utf-8" enctype="multipart/form-data">
        <div class="formgroup container-fluid">
            <label for="naam">Auto Naam:</label>
            <input type="text" name="naam" value="" />
            <br>
            <label for="type" name="type" value=""> Type: </label>
            <input type="text" name="type" value="" />
            <br>
            <label for="prijs">Prijs:</label>
            <input type="text" name="prijs" value="€" />
            <br>
            <label for="brandstof">Brandstof:</label>
<select id="brandstof">
  <option value="Benzine">Benzine</option>
  <option value="Diesel">Diesel</option>
  <option value="lpg">lpg</option>
  <option value="elektriciteit">elektriciteit</option>
</select>
<br>
<label for="status">Status:</label>
<select id="status">
<option value="nieuw">nieuw</option>
<option value="gebruikt">gebruikt</option>
</select>
<br>

<label for="km">Aantal KM::</label>
<input type="text" name="km" value="" />
<br>
<label for="bouwjaar">Bouwjaar:</label>
<input type="number" name="bouwjaar" min="1900" max="2021"/>
<br>

<label for="transmissie">Transmissies:</label>
<select id="Transmissies">
  <option value="Automaat">Automaat</option>
  <option value="Handmatig">Handmatig</option>
</select>
<br>
<label for="nummerbord">Nummerbord:</label>
<input type="text" name="nummerbord" value="" />
<br>
        </div>
        <div class="formgroup container-fluid">
            <input type="file" name="image" accept=".png"/>
            <input type="file" name="image1" accept=".png"/>
<br>

            <input type="file" name="image2" accept=".png"/>
            <input type="file" name="image3" accept=".png"/>
        </div>
        <div class="formgroup container-fluid">
            <label for="submit">Verstuur naar de database</label><br />
            <input type="submit" name="submit" value="verzenden" />
        </div>
    </form>
</div>
</center>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>