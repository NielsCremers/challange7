<?php 
//database voor de kantine
// DB credentials.
define('DB_HOST','localhost:3306');
define('DB_USER','nielsiecremers');
define('DB_PASS','cJ3j06k!');
define('DB_NAME','db_4_6_products');
// Establish database connection.
try
{
$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS);
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
?>